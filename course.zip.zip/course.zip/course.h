/**
 * @file course.h
 * @author yangs192@mcmaster.ca
 * @brief Course library for managing courses, including Course type definition 
 *        and Course functions.
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include "student.h"
#include <stdbool.h>
 
 /**
  * Course type stores a course with course name, code, 
  * an array of students in the course, and number of students
  * 
  */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * Course function declaration
 */
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


