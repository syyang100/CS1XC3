 /**
 * @file student.c
 * @author yangs192@mcmaster.ca
 * @brief Student library for managing students, including definitions of Student
 *        function. 
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/** 
 * Add a new grade to the student's grades (an array)
 * 
 * @param a student and the student's grade to be add 
 * @return nothing
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++;
  /**
   * if there is no grade for the student, add_grade function must create a dynamically allocated 
   * student's grades array that is initially able to store one (and only one) grade.
   * 
   */
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  /**
   * if there are more than one grades in student's grade array (including the one to be added), 
   * then student's grade array should be dynamically reallocated with realloc()
   * 
   */
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}


/** 
 * Calculate the average of the student's grade in the grades array
 * 
 * @param a student 
 * @return a double that represents the average grade of the student
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}


/** 
 * Print a student, including the student's first and last name, 
 * student ID, a list of student's grade, and the student's average grade
 * 
 * @param a student
 * @return nothing
 */

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}


/** 
 * generate random a student, including the student's first and last names, 
 * student ID, and grades
 * 
 * @param an integer represents the total number of grades for a student
 * @return a student
 */

Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  /**
   * use a for-loop to generate a 10 digits ID
   * 
   */

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}