 /**
 * @file course.c
 * @author yangs192@mcmaster.ca
 * @brief Course library for managing courses, including definitions of Course functions.
 * @version 0.1
 * @date 2022-04-07

 * @copyright Copyright (c) 2022
 * 
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
 /** 
 * @brief Add a new student to the course 
 * @param course a course of course type
 * @param student a student of student type
 * @return nothing
 */


void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  /* 
    if there is no student in the course, enroll_student function must create a dynamically 
            allocated array that is initially able to store one (and only one) student for the course
   */
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  /*
   * if there are more than one student in the course (including the student to be added),
   * then the course's student array should be dynamically reallocated with realloc()
   * 
   */
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/** 
 * @brief Print a course, including the course's name, course code, total_number of students, 
          and print each student in the course 
 * 
 * @param course a course of course type
 * @return nothing
 */


void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/** 
 * @brief find the student with the maximum average grade using find-maximum algorithm 
 * 
 * @param course a course of course type 
 * @return Student* a student  of student type that represent the top student
 *          (return NULL if there is no student in the course)
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  /*
   *  get the maximum average using for loop, use max_average to track the student 
   *  with highest maximum
   */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/** 
 * @brief count the number of students who pass the course and get the students as a 
          dynamically allocated array
 * @param course a course of course type
 * @param total_passing a pointer of integer type that represents the number of students
 *        who pass the course 
 * @return Student* a dynamically allocated array of students who pass the course 
 *          (return NULL if there is no student in the course)
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}