/**
 * @file student.h
 * @author yangs192@mcmaster.ca
 * @brief Student library for managing students, including Student type definition 
 *        and Student functions declarations.
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief student type definition 
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**<first name of the student*/
  char last_name[50]; /**<last name of the student*/
  char id[11];        /**<student ID*/
  double *grades;     /**<the grades of the student*/
  int num_grades;     /**<the number of grades the student has*/
} Student;

/**
 * @brief function declaration
 */

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
