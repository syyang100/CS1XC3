/**
 * @file course.h
 * @author yangs192@mcmaster.ca
 * @brief Course library for managing courses, including Course type definition 
 *        and Course functions declaration.
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include "student.h"
#include <stdbool.h>
 
 /**
  * @brief Course type stores a course with course name, code, 
  * an array of students in the course, and number of students
  * 
  */
typedef struct _course 
{
  char name[100]; /**<course name*/
  char code[10];  /**<course code*/
  Student *students; /**<an array of all students in the course*/
  int total_students; /**<total number of students in the course*/
} Course;

/**
 * Course function declaration
 */
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


